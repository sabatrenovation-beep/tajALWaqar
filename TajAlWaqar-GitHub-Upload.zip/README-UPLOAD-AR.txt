تاج الوقار — رفع المشروع إلى GitHub من الهاتف

المستودع:
sabatrenovation-beep/tajALWaqar

ارفع هذه الملفات بنفس المجلدات تمامًا:
- settings.gradle
- build.gradle
- gradle.properties
- app/build.gradle
- app/src/main/AndroidManifest.xml
- app/src/main/java/com/tajalwaqar/app/MainActivity.java
- app/src/main/res/values/styles.xml
- .github/workflows/build-apk.yml

بعد رفع الملفات:
1) اضغط Commit changes.
2) افتح تبويب Actions.
3) اختر Build Taj Al-Waqar V61 APK.
4) افتح آخر تشغيل.
5) بعد نجاحه ستجد Artifact باسم TajAlWaqar-V61-APK.
6) افتحه لتحميل APK وتثبيته على الهاتف.

مهم:
هذا التطبيق يفتح https://taj-al-waqar.fr
ويستخدم Android SpeechRecognizer الأصلي بدل Chrome.
