package com.tajalwaqar.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 10;

    private WebView webView;
    private SpeechRecognizer recognizer;
    private boolean listening = false;
    private String language = "ar-SA";
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new SpeechBridge(), "AndroidSpeech");

        webView.loadUrl("https://taj-al-waqar.fr/?android_native=61");
    }

    private void requestOrStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        startRecognition();
    }

    private void createRecognizer() {
        if (recognizer != null) return;

        // نفس عائلة المحرك التي نجحت في V97.
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);

        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                js("window.onNativeSpeechStart && window.onNativeSpeechStart()");
            }

            @Override public void onBeginningOfSpeech() {}

            @Override public void onRmsChanged(float rmsdB) {
                js("window.onNativeSpeechLevel && window.onNativeSpeechLevel(" + rmsdB + ")");
            }

            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}

            @Override public void onError(int error) {
                if (!listening) return;

                if (error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    restart();
                    return;
                }

                js("window.onNativeSpeechError && window.onNativeSpeechError(" +
                        quote(errorMessage(error)) + ")");
                restart();
            }

            @Override public void onResults(Bundle results) {
                ArrayList<String> list =
                    results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                if (list != null && !list.isEmpty()) {
                    String text = list.get(0);
                    if (text != null && !text.trim().isEmpty()) {
                        js("window.onNativeSpeechFinal && window.onNativeSpeechFinal(" +
                                quote(text.trim()) + ")");
                    }
                }
                if (listening) restart();
            }

            @Override public void onPartialResults(Bundle partialResults) {
                ArrayList<String> list =
                    partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                if (list != null && !list.isEmpty()) {
                    String text = list.get(0);
                    if (text != null && !text.trim().isEmpty()) {
                        js("window.onNativeSpeechPartial && window.onNativeSpeechPartial(" +
                                quote(text.trim()) + ")");
                    }
                }
            }

            @Override public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.onNativeSpeechError && window.onNativeSpeechError(" +
                    quote("خدمة التعرف الصوتي غير متوفرة على الهاتف") + ")");
            return;
        }

        createRecognizer();
        listening = true;

        try { recognizer.cancel(); } catch (Exception ignored) {}

        try {
            recognizer.startListening(makeIntent());
        } catch (Exception e) {
            js("window.onNativeSpeechError && window.onNativeSpeechError(" +
                    quote("تعذر بدء محرك Android Speech") + ")");
        }
    }

    private Intent makeIntent() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        return i;
    }

    private void restart() {
        handler.postDelayed(() -> {
            if (!listening || recognizer == null) return;
            try {
                recognizer.cancel();
                recognizer.startListening(makeIntent());
            } catch (Exception ignored) {}
        }, 300);
    }

    private void stopRecognition() {
        listening = false;
        handler.removeCallbacksAndMessages(null);

        if (recognizer != null) {
            try { recognizer.stopListening(); } catch (Exception ignored) {}
            try { recognizer.cancel(); } catch (Exception ignored) {}
        }

        js("window.onNativeSpeechStop && window.onNativeSpeechStop()");
    }

    private String errorMessage(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "خطأ في تسجيل الصوت";
            case SpeechRecognizer.ERROR_CLIENT: return "خطأ من التطبيق";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "إذن الميكروفون غير متاح";
            case SpeechRecognizer.ERROR_NETWORK: return "مشكلة في الشبكة";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "انتهت مهلة الشبكة";
            case SpeechRecognizer.ERROR_NO_MATCH: return "لم يتم التعرف على كلمات واضحة";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "خدمة التعرف الصوتي مشغولة";
            case SpeechRecognizer.ERROR_SERVER: return "خطأ في خدمة التعرف الصوتي";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "لم يُسمع كلام";
            default: return "خطأ التعرف الصوتي: " + error;
        }
    }

    private void js(String code) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(code, null);
        });
    }

    private String quote(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r") + "\"";
    }

    @Override public void onRequestPermissionsResult(
            int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_MIC && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startRecognition();
        } else if (requestCode == REQ_MIC) {
            js("window.onNativeSpeechError && window.onNativeSpeechError(" +
                    quote("يجب السماح بالميكروفون") + ")");
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        listening = false;
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    public class SpeechBridge {
        @JavascriptInterface public void startRecognition(String lang) {
            language = (lang == null || lang.trim().isEmpty()) ? "ar-SA" : lang.trim();
            runOnUiThread(MainActivity.this::requestOrStart);
        }

        @JavascriptInterface public void stopRecognition() {
            runOnUiThread(MainActivity.this::stopRecognition);
        }

        @JavascriptInterface public void notifyReady() {
            js("window.onNativeSpeechReady && window.onNativeSpeechReady()");
        }
    }
}
